
load("yaleA_3viewratio10_1.mat_r_S_result_")

% 定义文件夹名称
folderName = 'paramteranlysis_image';

% 检查文件夹是否存在，如果不存在则创建
if ~exist(folderName, 'dir')
    mkdir(folderName);
end
rowsToRemove = r_S(:, 1) == 10000;
r_S(rowsToRemove, :) = [];
rowsToRemove = r_S(:, 1) == 1000;
r_S(rowsToRemove, :) = [];

rowsToRemove = r_S(:, 2) == 10000;
r_S(rowsToRemove, :) = [];
rowsToRemove = r_S(:, 2) == 1000;
r_S(rowsToRemove, :) = [];

A = [];
Final = r_S;



start_value = 6;%设置初始值
step_size = 9; %设置步长 可以观察到Final数据集的第三个参数以8为一次循环。
end_value = length(Final);
for iv= start_value:step_size:end_value
    A = [A;Final(iv,:)];
end


% 删除不需要的列元素。
A(:, [1,2,3,5,6,7,8,9]) = [];
A = reshape(A,7,7);
A = A';
% figure('Position', [100, 100, 800, 600])
barWidth = 0.6;
x_values = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4]; % X轴坐标
y_values = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4]; % Y轴坐标
b = bar3(A,barWidth);

set(gca,'FontName','Times New Roman','FontSize',10);
zlabel('ACC');
% 设置X和Y坐标刻度
xticks(1:numel(x_values));
xticklabels(string(x_values));
yticks(1:numel(y_values));
yticklabels(string(y_values));

% 设置轴标签

xlabel('λ1');
ylabel('λ2');
title('YaleA: ε=0.6');
% 添加颜色映射
% colormap('jet');
% 添加颜色条
colorbar;
axis tight;
saveas(gcf, fullfile(folderName, 'BBC0.1_1.jpg'));
