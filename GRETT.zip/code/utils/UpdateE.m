function [ output_args ] = UpdateE( input_args )


end

