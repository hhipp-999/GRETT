clear
clc
ours = [ 97.0961   96.7987   96.1233   95.9301   96.1941   96.4149   96.4110   96.8792   96.8430   96.0095

 ];

% 对比方法的ACC
baseline = [      82.5286   82.7805   85.4906   83.6563   88.1029   85.1934   83.2996   80.1797   80.2234   72.6451





];

% 进行配对单尾 t 检验（假设 ours > baseline）
[h, p, ci, stats] = ttest(ours, baseline, 'Tail', 'both');

% 打印结果
if h == 1
    fprintf('The performance difference is statistically significant (p = %.4f).\n', p);
else
    fprintf('The performance difference is NOT statistically significant (p = %.4f).\n', p);
end

fprintf('t-statistic: %.4f, df: %d\n', stats.tstat, stats.df);
fprintf('p: %.4f, df: %d\n', p);


% yaleA : 96.7570   97.3072   96.8565   96.6523   96.4974   96.7517   95.7553   97.4519   96.6623   97.7085
% ORL: 97.1006   96.0435   97.4314   96.0046   99.5322   98.3682   95.5304   97.2931   95.4184   97.2775
% Eyaleb 95.8071   96.5716   96.3505   96.7708   96.5508   96.6753   95.9324   96.4367   96.2565   96.6483
% flower 97.0961   96.7987   96.1233   95.9301   96.1941   96.4149   96.4110   96.8792   96.8430   96.0095
