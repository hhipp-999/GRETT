clear;
 clc;
 warning off
addpath(genpath('datasets')); 
addpath('datasets', 'utils');
addpath('ATTNA_order_5');
% load('ORL_mtv');
% load('ORL_mtvratio50.mat');

% 
% load('ORL.mat');
% load('ORLratio10.mat');

% 
% load("ORL.mat")
% dataname = "ORLratio10.mat";
% load(dataname);
% % 
load("yaleA_3view.mat")
dataname = "yaleA_3viewratio10.mat";
load(dataname);

% % 
% load("MSRCV1.mat") 
% dataname = "MSRCV1ratio10.mat";
% load(dataname);

% load("Caltech101-7.mat")
% dataname = "Caltech101-7ratio10_1.mat";
% load(dataname);
 
% load("EYaleB10.mat")
% dataname = "EYaleB10ratio10.mat";
% load(dataname);

% load("flower17_numberOf_170_Kmatrix.mat")
% dataname = "flower17_numberOf_170_Kmatrixratio10.mat";
% load(dataname);

% load("CCV")
% dataname = "CCVratio10_1.mat";
% load(dataname);

% load("uci-digit.mat")
% dataname = "uci-digitratio10.mat";
% load(dataname);

% load("Hdigit.mat")
% dataname = "Hdigitratio70.mat";
% load(dataname);

temp=0;
% 
lambda1=[1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2];
lambda2=[1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2];
ri_RSE_threshold = [0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9];

		
% lambda1=[1e-4,2e-4,3e-4,4e-4,5e-4,1e-3,2e-3,3e-3,4e-3,5e-3,1e-2,2e-2,3e-2,4e-2,5e-2,1e-1,2e-1,3e-1,4e-1,5e-1,1e1,2e1,3e1,4e1,5e1,1e2,2e2,3e2,4e2,5e2,1e3,2e3,3e3,4e3,5e3,1e4,2e4,3e4,4e4,5e4];
% lambda2=[1e-4,2e-4,3e-4,4e-4,5e-4,1e-3,2e-3,3e-3,4e-3,5e-3,1e-2,2e-2,3e-2,4e-2,5e-2,1e-1,2e-1,3e-1,4e-1,5e-1,1e1,2e1,3e1,4e1,5e1,1e2,2e2,3e2,4e2,5e2,1e3,2e3,3e3,4e3,5e3,1e4,2e4,3e4,4e4,5e4];
% ri_RSE_threshold = [0.1];

% lambda1=[0.01,0.03,0.05,0.07,0.09];
% lambda2=[0.0001,0.0003,0.0005,0.0007,0.0009];
% ri_RSE_threshold = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9];

% ORL  0.001 0.0001 0.6 50% 
% 
% lambda1=[1];	
% lambda2=[1];
% ri_RSE_threshold = [0.1];

% lambda1 = 2.^(-15:1:15);
% lambda2 = 2.^(-15:1:15);
% % lambda1 = 2.^(-20:1:15);
% % lambda2 = 2.^(-20:1:15);
% % % lambda1 = 2.^(-50:1:-15);
% % % lambda2 = 2.^(-50:1:-15);
% ri_RSE_threshold = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9];
% lambda1=[1];
% lambda2=[1];
% ri_RSE_threshold = [0.1];

% lambda3=[0.1];
param.index_data = 1;
param.ratio = 0.05;
param.dim_h = 100;
param.epson = 1e-5;
param.save_path = './results/ours/';
R_U =[];
la_US =[];
R_S = [];
CAK = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%% test
% param.index_data = 2;
% param.ratio = 0;
iter_rand=1;
% group_data = 1;
% group_ratio = 0.3;%0.0:0.1:0.4;
% IndicatorName =('ORL_mtvratio50.mat');
for iv = 1 : length(X)
    X{iv} = X{iv}';
end

gt = Y;
cls_num = length(unique(gt));
clear Y
Indicator = folds{1};
for iv = 1:length(X)
    X1 = X{iv};
    ind_0 = find(Indicator(:,iv) == 0);
    ind_1 = find(Indicator(:,iv) == 1);
    % ---------- ��ʼKNNͼ���� ----------- %
    X1(:,ind_0) = [];
    options = [];
    options.NeighborMode = 'KNN';
    options.k = 3;
    options.WeightMode = 'Binary';      % Binary  HeatKernel  Cosine
    Z1 = full(constructW(X1',options));
    Z1 = Z1- diag(diag(Z1));
    linshi_W = diag(Indicator(:,iv));
    linshi_W(:,ind_0) = [];
    Z_ini{iv} = linshi_W*max(Z1,Z1')*linshi_W';
    clear Z1 linshi_W
end
% for iv = 1 :  length(X)
%     Z_ini{iv} = zeros(size(X{1},2));
% end
r_U =[];
ave_m =[];
std_m = [];
TIME = [];
iter_pp = 1 ;
folder_name = 'convergence_result';
for lam1 =1:length(lambda1)
    for lam2 =1:length(lambda2)
        for lam3  = 1  : length(ri_RSE_threshold)
            tic
            [U,S,Norm2] =algorithm1(X,Z_ini, gt, param,lambda1(lam1), lambda2(lam2),Indicator,ri_RSE_threshold(lam3));
            time = toc;
            %% 
             x=1:length(obj);
                set(gca,'FontName','Times New Roman','FontSize',10);
                plot(x, obj, '-o');
                title("Hdigit");
                xlabel('Number of Iterations');
                ylabel('objective value');

                 if ~exist(folder_name, 'dir')
                     mkdir(folder_name);
                 end
                 file_name = sprintf('%s_%d.png', 'Uci-digit', iter_pp);
                 full_file_path = fullfile(folder_name, file_name); 
                 exportgraphics(gcf, full_file_path, 'Resolution', 300); 
                 iter_pp = iter_pp + 1;
%             
            %% use U for clustering 
            Fng =  NormalizeFea(U,1);
            pre_labels = kmeans(real(Fng),cls_num,'maxiter',1000,'replicates',20,'EmptyAction','singleton');
            result_cluster = ClusteringMeasure(gt, pre_labels)*100;
            acc = result_cluster(1); nmi = result_cluster(2); purity = result_cluster(3);
            res11 = compute_f(gt, pre_labels);
            f = res11(1); percision = res11(2); rcall = res11(3);
            R_U = [R_U;acc,nmi,purity,f*100,percision*100,rcall*100];
            la_US = [la_US;lambda1(lam1),lambda2(lam2),ri_RSE_threshold(lam3)]; 
%             r_U = [la_US,R_U];
            U_temp{lam1}{lam2}{lam3} = U;
            for iv = 1 : 1
                pre_labels = kmeans(real(Fng),cls_num,'maxiter',1000,'replicates',20,'EmptyAction','singleton');
                result_cluster_ten = ClusteringMeasure(gt, pre_labels)*100;
                res_TEN_K(iv,:) =[result_cluster_ten];
            end
            res_TEN_K
%             mean(res_TEN_K)
%             std(res_TEN_K)
%             %% use S for clustering 
%             C = SpectralClustering(S,cls_num);
%             [A nmi avgent] = compute_nmi(gt,C);
%             result_cluster_2 = ClusteringMeasure(gt, C)*100;
%             res_f = compute_f(gt,C);
%             R_S = [R_S;result_cluster_2(1),result_cluster_2(2), result_cluster_2(3),res_f(1)*100,res_f(2)*100,res_f(3)*100];
%             r_S = [la_US,R_S];
%             CAK = CAK +1;
%             fprintf("%d-th\n",CAK)
%             ACC=result_cluster_2(1); NMI = result_cluster_2(2); Purity = result_cluster_2(3);
            ave_m =[ave_m;mean(res_TEN_K)] ;
            std_m = [std_m;std(res_TEN_K)];
            TIME = [TIME;time];
            r_U = [la_US,R_U, ave_m, std_m,TIME];
            
            if (temp<acc)
                temp=acc;
            end
%             for iv = 1 : 10
%                 C = SpectralClustering(S,cls_num);
%                 result_cluster_ten_C = ClusteringMeasure(gt, C)*100;
%                 res_TEN_C(iv,:) =[result_cluster_ten_C];
%             end
%             mean(res_TEN_C)
%             std(res_TEN_C)
        fprintf('ACC=%.4f,NMI=%.4f, Purity=%.4f,  lambda1=%.4f,lambda2=%.4f, ri_RSE_threshold=%.4f,  AccMax=%.4f\n',acc,nmi,purity, lambda1(lam1) , lambda2(lam2) ,ri_RSE_threshold(lam3),temp);
        end
    end
end

% filepath = 'result'; 
% filename  = dataname + "_r_U"+"_result_"+ ".mat";
% save(fullfile(filepath, filename), 'r_U');
% 
% filepath = 'result'; 
% filename  = dataname + "_r_S"+"_result_"+ ".mat";
% save(fullfile(filepath, filename), 'r_S');
% % 
% [m,n] = max(R_U(:,3));
% R_U(n,:)
%  
% [m,n] = max(R_S(:,3));
% R_S(n,:)