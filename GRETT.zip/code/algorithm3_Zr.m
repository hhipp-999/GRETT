
function [U,S_C] = algorithm1(X,Z_ini, gt, param,lambda1,lambda2,Indicator,ri_RSE_threshold)
%%%%%%%%%%%%%%%%%%%%%%%%%% param
    V = length(X);
    cls_num = length(unique(gt));
    for v=1:V
        X{v}=NormalizeData(X{v});
    end
    N = size(X{1}, 2);
    sX = [N, N, V+1];
    Isconverg = 0;
    ModCount = 3;
    iter = 0;
    mu = 10e-5; max_mu = 10e10; iter_mu = 1.5;
    pho = 10e-4; max_pho = 10e12; iter_pho = 2;
%% initail
    Z = Z_ini;
    tem_Z = zeros(N,N);
    for iv = 1 : length(Z)
        tem_Z = tem_Z + (abs(Z{iv})+(abs(Z{iv}))')./2;
    end
    Z_hat = tem_Z./V;
    nv = length(Z);
    Nsamp = size(Z{1},1);
    U = zeros(Nsamp,cls_num);
    H = zeros(param.dim_h, N);

    for v=1:V
        index{v} = diag(Indicator(:,v));
        tmpX = X{v};
        inTmp = find(Indicator(:,v)==0);
        tmpX(:,inTmp) = 0;
        Xc{v} = tmpX;
%         E1{v} = zeros(size(X{v},1), N);
        E1{v} = zeros(size(X{v},1), N);
        E2{v} = zeros(size(X{v},1), N);
%         E1{v} = 0.1*randn(size(X{v},1), N);
%         E2{v} = 0.1*randn(size(X{v},1), N);
        Y1{v} = zeros(size(X{v},1), N);
        Y2{v} = zeros(size(X{v},1), N);
        Y3{v} = zeros(size(X{v},1), N);
        P{v} = 0.1*randn(size(X{v},1), param.dim_h);
        alpha{v} = 1;
    end
    alpha{V+1} = 1;

    for v=1:V+1
%         G{v} = zeros(N,N);
        Y{v} = zeros(N,N);
        S{v} = zeros(N,N);
    end

%     Er = zeros(param.dim_h,N);
    Er = zeros(param.dim_h,N);
%     Er = 0.1*randn(param.dim_h,N);
    Zr = zeros(N,N);
    Y4 = zeros(param.dim_h,N);

%     Z_tensor = cat(3, Z{:,:});
%     G_tensor = cat(3, G{:,:});
    Y_tensor = cat(3, Y{:,:});
% 
%     w = zeros(N*N*(V+1), 1);
%     g = zeros(N*N*(V+1), 1);

    for i=1:ModCount+1
        YT{i} = Y_tensor;
    end
U = zeros(Nsamp,cls_num);
%% ATTNA parameter
rX = [N/cls_num,cls_num,N/cls_num,cls_num,V+1];
% ri_RSE_threshold_list = [0.5];
% ri_RSE_threshold = ri_RSE_threshold_list(1);
ir = 2;
rank=ir*ones(1,10);
G{1} = rand(rX(1),rank(1),rank(2),rank(3),rank(4));
G{2} = rand(rX(2),rank(5),rank(6),rank(7),rank(1));
G{3} = rand(rX(3),rank(8),rank(9),rank(2),rank(5));
G{4} = rand(rX(4),rank(10),rank(3),rank(6),rank(8));
G{5} = rand(rX(5),rank(4),rank(7),rank(9),rank(10));

%% ATTNA parameter
ATTNA_para.ir = 2;
% reshape X to 5th-order tensor
ATTNA_para.rX = [N/cls_num,cls_num,N/cls_num,cls_num,V+1];

% new_ten.m parameter
ATTNA_para.new_ten_iter_max = 10;
ATTNA_para.new_ten_tol=1e-3;

% prue_ten.m parameter
ATTNA_para.prune_theshold = 0.2;
ATTNA_para.prue_gap = 4;
ATTNA_para.prue_ten_iter_max = 50;
ATTNA_para.prue_ten_tol=1e-3;

%rank_increase parameter
ATTNA_para.ri_RSE_threshold = ri_RSE_threshold; %epsilon,0.5
ATTNA_para.ri_step = 1;
ATTNA_para.ri_update_iter = 5;
ATTNA_para.ri_iter_max = 50;
ATTNA_para.ri_tol=1e-3;
Norm1 = []; Norm2 = []; Norm3 = [];Norm4 = [];
    %%  train
    while(Isconverg == 0)
%         fprintf('----processing iter %d--------\n', iter+1);
        
      %% updata H
      tmp1 = 0;tmp2 = 0;
      for v = 1 : V
          tmp1 = tmp1 + mu*P{v}'*P{v};
          tmp2 = tmp2 + P{v}'*Y1{v} + mu*P{v}'*Xc{v} - mu*P{v}'*E1{v};
      end
      H_left = tmp1 + mu * eye(size(P{1},2),size(P{1},2));
      H_right = mu*(Zr*Zr'-Zr-Zr');
      H_all = tmp2 + Y4*(Zr-eye(N)) + mu * Er * (eye(N)-Zr');          
      H = lyap(H_left,H_right,H_all);
%       clear tmp1 tmp2
      %% update Z{v}
        for i=1:N
            for l= 1:N
                P_tmp(l,i) = (norm(U(l,:)-U(i,:),2))^2;
                if Z_hat(l,i)>0
                    tem_P(l,i) = P_tmp(l,i);
                elseif Z_hat(l,i)==0
                    tem_P(l,i) = 0;  
                else 
                    tem_P(l,i) = -P_tmp(l,i);
                end
            end
        end
      clear i l
      temZ = zeros(N,N);
      for iv = 1 : nv
          tmp1 = pho*alpha{iv}*alpha{iv}*S{iv}-alpha{iv}*Y{iv} + Xc{iv}'*Y3{iv} + mu*Xc{iv}'*Xc{iv}- mu*Xc{iv}'*E2{iv}-(lambda2/mu)*tem_P;
          tmp2 = pho*alpha{iv}*alpha{iv}*eye(N) + mu * Xc{iv}' * Xc{iv};
          Z{iv} = tmp2\tmp1;
          temZ = temZ + (abs(Z{iv})+(abs(Z{iv}))')./2;
      end
      Z_hat = temZ./nv;
      clear iv
      %% update P{iv}
      for iv = 1 :nv
          P{iv} = (Xc{iv}+Y1{iv}/mu-E1{iv})*H'*inv(H*H');
      end
      %% update Xc{iv}
      for v = 1 : V
        tmp1 = eye(N) + index{v} + (eye(N)-Z{v})*(eye(N)-Z{v}');
        tmp2 = E1{v}+P{v}*H + X{v}*index{v} + E2{v}*(eye(N)-Z{v}') - (Y1{v}+Y2{v}*index{v}+Y3{v}*(eye(N)-Z{v}'))/mu ;
        Xc{v} = tmp2/tmp1;
      end
      clear tmp1 tmp2
      %% update Zr
      tmp1 = H'*Y4 + mu*(H'*H) - mu*H'*Er + pho * alpha{V+1}*alpha{V+1}*S{V+1} - alpha{V+1}*Y{V+1};
      Zr = (mu * (H'*H) + pho*eye(N)) \ tmp1;
      %% update E 
      % 1. divided optimize 
%       % update E1 ok
%       E1 = UpdateE1(Xc, P, H, Y1, mu, lambda1, V);
%       % update E2
%       E2 = UpdateE2(Xc, Z, Y3, mu, lambda1, V);
%       % update Er
%       Er = UpdateEr(H,Zr,Y4,mu,lambda1);

      % 2. together optimize
      F1 = [];
      for k=1:V
          F1 = [F1;Xc{k}-P{k}*H+Y1{k}/mu];
      end
      for k=1:V
          F1 = [F1;Xc{k}-Xc{k}*Z{k}+Y3{k}/mu];
      end
      F1 = [F1;H-H*Zr+Y4/mu];

      [Econcat] = solve_l1l2(F1,lambda1/mu);
      start_index = 1;
      for i = 1:V
          end_index = start_index + size(X{i}, 1) - 1;
          E1{i} = Econcat(start_index:end_index, :);
          start_index = end_index + 1;
      end
      for i = 1:V
          end_index = start_index + size(X{i}, 1) - 1;
          E2{i} = Econcat(start_index:end_index, :);
          start_index = end_index + 1;
      end
      Er = Econcat(start_index:end, :);
      %% update alpha
%       for iv  = 1 : nv
%           if  norm(E2{iv}, 'fro') == 0
%               alpha{iv} = 1;
%           else 
%               F_norm = norm(E2{iv}, 'fro');
%               alpha{iv} = 1/F_norm;
%           end
%       end
%       if  norm(Er, 'fro') == 0
%           alpha{V+1} = 1;
%       else 
%           F_norm = norm(Er, 'fro');
%           alpha{V+1} = 1/F_norm;
%       end

      for iv = 1 : nv
          F_norm = norm(E2{iv}, 'fro')+0.001;
          alpha{iv} = 1/F_norm;
      end
%       F_norm_r =  norm(Er, 'fro')+0.001;
%       alpha{nv+1} = 1 / F_norm_r;

    tmp_a=0;
    for iv = 1:length(alpha)
        tmp_a = tmp_a + alpha{iv};
%         alpha{iv} = alpha{iv}/tmp_a;
    end
    for iv = 1 : length(alpha)
        alpha{iv} = alpha{iv}/tmp_a;
    end
% alpha




      %% update U
          Z_hat = (Z_hat+Z_hat')/2;
          D = diag(sum(Z_hat));
          L = D-Z_hat;
          DN = diag( 1./sqrt(sum(Z_hat)+eps) );
          LapN = speye(N) - DN * Z_hat * DN;
          [~,~,vN] = svd(LapN);
          kerN = vN(:,N-cls_num+1:N);
          for i = 1:N
              U(i,:) = kerN(i,:) ./ norm(kerN(i,:)+eps);
          end
       %% Update tensor S
       for iv = 1 : V
           Z_tensor(:,:,iv) = Z{iv} * alpha{iv};
       end
       Z_tensor(:,:,V+1) =Zr * alpha{V+1};
       z = Z_tensor(:);
       Y_tensor = cat(3, Y{:,:});
       y = Y_tensor(:);
       %% t-svd
%        [s, objV] = wshrinkObj(z + (1/pho)*y,1/pho,sX,0,3);

        %% ATTNNA
       [S_tensor,rank,G] = ATTNA(Z_tensor + 1/pho*Y_tensor,G,rank,iter,sX,ATTNA_para);
       s = S_tensor(:);
       %% update Y lagrgene
       y = y + pho*(z - s);
       %% update lagrgene
       for v = 1 : V
           Y1{v} = Y1{v} + mu*(Xc{v} - P{v}*H - E1{v});
%            Y2{v} = Y2{v} + mu*(Xc{v}*index{v} - X{v}*index{v});
           Y2{v} = Y2{v} + mu*(X{v}*index{v}-Xc{v}*index{v});
           Y3{v} = Y3{v} + mu*(Xc{v} - Xc{v}*Z{v} - E2{v});
       end
       Y4 = Y4 + mu*(H- H*Zr-Er);
       
       mu = min(mu*iter_mu, max_mu);
       pho = min(pho*iter_pho,max_pho);
% CONVERGENCE-------------------- 
        Isconverg = 1;
        for v=1:V 
            if (norm(Xc{v} - Xc{v}*Z{v} - E2{v}, inf)>param.epson)
                history.norm_1 = norm(Xc{v} - Xc{v}*Z{v} - E2{v},inf);
%                 fprintf('    norm1 %7.10f    ', history.norm_1);
                Isconverg = 0;
            end
            S_tensor = reshape(s, sX);
            S{v} = S_tensor(:,:,v);
            Y_tensor = reshape(y, sX);
            Y{v} = Y_tensor(:,:,v);  

            if (norm(Z{v}-S{v}, inf)>param.epson)
                history.norm_2 = norm(Z{v}-S{v},inf);
                fprintf('    norm2 %7.10f    ', history.norm_2);
                Isconverg = 0;
            end
            if (norm(Xc{v}-P{v}*H - E1{v}, inf)>param.epson)
                history.norm_3 = norm(Xc{v}-P{v}*H -E1{v},inf);
%                  fprintf('    norm3 %7.10f \n   ', history.norm_3);
                Isconverg = 0;
            end

            if (norm(H-H*Zr-Er)>param.epson)
                history.norm_4 = norm(H-H*Zr-Er,inf);
%                 fprintf('    norm4 %7.10f \n   ', history.norm_4);
                Isconverg = 0;
            end
        end

        if (iter>100)
            Isconverg = 1;
        end
        iter = iter + 1;
        Norm1 = [Norm1;norm(Xc{1} - Xc{1}*Z{1} - E2{1},inf)];
        Norm2 = [Norm2;norm(Z{1}-S{1},inf)];
        Norm3 = [Norm3;norm(Xc{1}-P{1}*H - E1{1},inf)];
        Norm4 = [Norm4;norm(H-H*Zr-Er,inf)];
    end
x=1:length(Norm4);
set(gca,'FontName','Times New Roman','FontSize',10);
% plot(x, Norm4);
plot(x, Norm1, '-o', x, Norm2, '-*', x, Norm3, '-x', x, Norm4, '-+');
xlabel('Number of Iterations');
ylabel('Stop Critria');
legend('Xc-PH-E1','Z-G','Xc-XcZ-E2','H-HZr-Er')
% saveas(gcf, 'my_plot.png'); 
    S_C = 0;
    for k=1:V
        S_C = S_C + abs(Z{k})+abs(Z{k}');
    end

end