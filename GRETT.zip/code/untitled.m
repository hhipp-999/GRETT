clc
clear
mu = 82.41;
sigma = 4.18;
n = 10;

% 构造一个标准正态分布样本（均值为 0，标准差为 1）
x_standard = randn(1, n);

% 将其缩放为给定标准差，并平移为给定均值
x = mu + sigma * (x_standard - mean(x_standard)) / std(x_standard);

% 验证
fprintf('mean = %.4f, std = %.4f\n', mean(x), std(x));
disp(x);